// A small XPLM host double for lifecycle and control-ownership regression tests.
#include "XPLMDataAccess.h"
#include "XPLMDisplay.h"
#include "XPLMGraphics.h"
#include "XPLMMenus.h"
#include "XPLMNavigation.h"
#include "XPLMPlugin.h"
#include "XPLMProcessing.h"
#include "XPLMUtilities.h"

#include <algorithm>
#include <array>
#include <cmath>
#include <cstdlib>
#include <cstring>
#include <iostream>
#include <map>
#include <string>
#include <vector>

PLUGIN_API int XPluginStart(char*, char*, char*);
PLUGIN_API int XPluginEnable();
PLUGIN_API void XPluginDisable();
PLUGIN_API void XPluginStop();
PLUGIN_API void XPluginReceiveMessage(XPLMPluginID, int, void*);

namespace {
struct Data {
    double scalar{};
    std::array<int, 500> integers{};
    std::array<float, 500> floats{};
};
struct Handler {
    XPLMCommandCallback_f callback{};
    void* context{};
};
std::map<std::string, Data> data;
std::map<std::string, Handler> handlers;
std::string logOutput;
std::vector<std::string> drawn;
XPLMCreateFlightLoop_t loop{};
XPLMCreateWindow_t window{};
bool scheduled{};
bool inFms{};
int destination{};
int yokeWrites{};
int throttleWrites{};
int parentMenu{};
int submenu{};

constexpr const char* pitchFlag = "sim/operation/override/override_joystick_pitch";
constexpr const char* rollFlag = "sim/operation/override/override_joystick_roll";
constexpr const char* throttleFlag = "sim/operation/override/override_throttles";
constexpr const char* apFlag = "sim/cockpit2/autopilot/servos_on";
constexpr const char* throttle = "sim/flightmodel/engine/ENGN_thro_use";
constexpr const char* axes = "sim/joystick/joystick_axis_values";
constexpr const char* assignments = "sim/joystick/joystick_axis_assignments";

void require(bool condition, const char* message) {
    if (!condition) {
        std::cerr << message << '\n' << logOutput;
        std::exit(EXIT_FAILURE);
    }
}

void set(const char* name, double value) { data[name].scalar = value; }

void invoke(const char* name) {
    auto& handler = handlers.at(name);
    require(handler.callback != nullptr, "command missing callback");
    require(handler.callback(&handler, xplm_CommandBegin, handler.context) == 1,
            "command swallowed normal X-Plane processing");
}

void tick(float dt = 0.025f) {
    require(scheduled, "flight loop not scheduled");
    loop.callbackFunc(dt, dt, 0, loop.refcon);
}

void assertOverrides(bool yoke, bool power) {
    require(data[pitchFlag].scalar == yoke && data[rollFlag].scalar == yoke &&
            data[throttleFlag].scalar == power, "unexpected position of override flags");
}

void click(int x, int y) {
    require(window.visible && window.handleMouseClickFunc, "panel not visible");
    window.handleMouseClickFunc(&window, window.left + x, window.top - y,
                                xplm_MouseDown, window.refcon);
}

void expectLabel(const char* prefix) {
    drawn.clear();
    require(window.drawWindowFunc != nullptr, "panel unavailable");
    window.drawWindowFunc(&window, window.refcon);
    require(std::any_of(drawn.begin(), drawn.end(), [prefix](const auto& value) {
        return value.find(prefix) != std::string::npos;
    }), prefix);
}
}  // namespace

XPLMDataRef XPLMFindDataRef(const char* name) { return &data[name]; }
XPLMDataTypeID XPLMGetDataRefTypes(XPLMDataRef) {
    return xplmType_Int | xplmType_Float | xplmType_Double | xplmType_IntArray | xplmType_FloatArray;
}
int XPLMCanWriteDataRef(XPLMDataRef) { return 1; }
float XPLMGetDataf(XPLMDataRef ref) { return static_cast<float>(static_cast<Data*>(ref)->scalar); }
int XPLMGetDatai(XPLMDataRef ref) { return static_cast<int>(static_cast<Data*>(ref)->scalar); }
double XPLMGetDatad(XPLMDataRef ref) { return static_cast<Data*>(ref)->scalar; }
void XPLMSetDatai(XPLMDataRef ref, int value) { static_cast<Data*>(ref)->scalar = value; }
void XPLMSetDataf(XPLMDataRef ref, float value) {
    static_cast<Data*>(ref)->scalar = value;
    ++yokeWrites;
}
int XPLMGetDatavi(XPLMDataRef ref, int* values, int offset, int count) {
    std::copy_n(static_cast<Data*>(ref)->integers.begin() + offset, count, values);
    return count;
}
int XPLMGetDatavf(XPLMDataRef ref, float* values, int offset, int count) {
    std::copy_n(static_cast<Data*>(ref)->floats.begin() + offset, count, values);
    return count;
}
void XPLMSetDatavf(XPLMDataRef ref, float* values, int offset, int count) {
    require(ref == &data[throttle] && count == 1, "throttle written to unexpected engine");
    std::copy_n(values, count, static_cast<Data*>(ref)->floats.begin() + offset);
    ++throttleWrites;
}

int XPLMCountFMSEntries() { return inFms ? 2 : 0; }
int XPLMGetDestinationFMSEntry() { return destination; }
void XPLMGetFMSEntryInfo(int index, XPLMNavType* type, char* name, XPLMNavRef*, int*, float* lat, float* lon) {
    *type = xplm_Nav_Fix;
    std::strcpy(name, index == 0 ? "FIRST" : "SECOND");
    *lat = 37.6f + index * 0.08f;
    *lon = -122.2f;
}

XPLMFlightLoopID XPLMCreateFlightLoop(XPLMCreateFlightLoop_t* setup) {
    require(setup->phase == xplm_FlightLoop_Phase_BeforeFlightModel, "wrong control update phase");
    loop = *setup;
    return &loop;
}
void XPLMScheduleFlightLoop(XPLMFlightLoopID, float interval, int) { scheduled = interval != 0; }
void XPLMDestroyFlightLoop(XPLMFlightLoopID) { loop = {}; scheduled = false; }
XPLMMenuID XPLMFindPluginsMenu() { return &parentMenu; }
XPLMMenuID XPLMCreateMenu(const char*, XPLMMenuID, int, XPLMMenuHandler_f, void*) { return &submenu; }
int XPLMAppendMenuItem(XPLMMenuID, const char*, void*, int) { return 0; }
void XPLMDestroyMenu(XPLMMenuID) {}
void XPLMRemoveMenuItem(XPLMMenuID, int) {}

XPLMCommandRef XPLMCreateCommand(const char* name, const char*) { return &handlers[name]; }
XPLMCommandRef XPLMFindCommand(const char* name) { return &handlers[name]; }
void XPLMRegisterCommandHandler(XPLMCommandRef ref, XPLMCommandCallback_f callback, int before, void* context) {
    require(before == 1, "expected a before handler");
    *static_cast<Handler*>(ref) = {callback, context};
}
void XPLMUnregisterCommandHandler(XPLMCommandRef ref, XPLMCommandCallback_f, int, void*) {
    *static_cast<Handler*>(ref) = {};
}
void XPLMDebugString(const char* message) { logOutput += message; }

void XPLMGetScreenBoundsGlobal(int* left, int* top, int* right, int* bottom) {
    *left = 0; *top = 1080; *right = 1920; *bottom = 0;
}
XPLMWindowID XPLMCreateWindowEx(XPLMCreateWindow_t* setup) { window = *setup; return &window; }
void XPLMGetWindowGeometry(XPLMWindowID, int* left, int* top, int* right, int* bottom) {
    *left = window.left; *top = window.top; *right = window.right; *bottom = window.bottom;
}
int XPLMGetWindowIsVisible(XPLMWindowID) { return window.visible; }
void XPLMSetWindowIsVisible(XPLMWindowID, int visible) { window.visible = visible; }
void XPLMBringWindowToFront(XPLMWindowID) {}
void XPLMDestroyWindow(XPLMWindowID) { window = {}; }
void XPLMSetWindowTitle(XPLMWindowID, const char*) {}
void XPLMSetWindowResizingLimits(XPLMWindowID, int, int, int, int) {}
void XPLMDrawTranslucentDarkBox(int, int, int, int) {}
void XPLMDrawString(float*, int, int, char* message, int*, XPLMFontID) { drawn.emplace_back(message); }

int main() {
    char name[256]{}, signature[256]{}, description[256]{};
    require(XPluginStart(name, signature, description) && XPluginEnable(), "could not start plugin");
    invoke("levelpilot/flight/toggle_panel");
    expectLabel("STANDBY");
    set("sim/flightmodel/failures/onground_any", 1);
    click(35, 68);
    expectLabel("Aircraft on ground");
    assertOverrides(false, false);

    set("sim/flightmodel/failures/onground_any", 0);
    set("sim/time/sim_speed", 1);
    set("sim/flightmodel/position/elevation", 1550);
    set("sim/flightmodel/position/y_agl", 1300);
    set("sim/flightmodel/position/indicated_airspeed", 105);
    set("sim/flightmodel/position/true_airspeed", 55);
    set("sim/flightmodel/position/groundspeed", 55);
    set("sim/flightmodel/position/latitude", 37.5);
    set("sim/flightmodel/position/longitude", -122.2);
    set("sim/aircraft/view/acf_Vs", 48);
    set("sim/aircraft/view/acf_Vne", 160);
    set("sim/aircraft/engine/acf_num_engines", 1);
    data["sim/flightmodel/engine/ENGN_running"].integers[0] = 1;
    data[throttle].floats[0] = 0.61f;
    data[assignments].integers[0] = 1;
    data[assignments].integers[1] = 4;
    data[axes].floats[0] = 0.5f;
    data[axes].floats[1] = 0.6f;

    set(apFlag, 1);
    click(35, 68);
    assertOverrides(false, false);
    expectLabel("Aircraft autopilot is on");
    set(apFlag, 0);
    set(rollFlag, 1);
    click(35, 68);
    require(data[pitchFlag].scalar == 0 && data[rollFlag].scalar == 1 &&
            data[throttleFlag].scalar == 0, "failed engage altered someone else's override");
    expectLabel("Control override conflict");
    set(rollFlag, 0);

    click(35, 68);
    assertOverrides(true, true);
    expectLabel("ENGAGED");
    tick();
    require(yokeWrites == 2 && throttleWrites == 1 &&
            std::abs(data[throttle].floats[0] - 0.61f) < 0.025f, "control capture produced a step");

    set("sim/cockpit2/autopilot/heading_dial_deg_mag_pilot", 40);
    set("sim/cockpit2/autopilot/altitude_dial_ft", 6000);
    set("sim/cockpit2/gauges/indicators/altitude_ft_pilot", 4985.30);
    set("sim/cockpit2/autopilot/airspeed_dial_kts_mach", 112);
    invoke("levelpilot/flight/panel_targets");
    expectLabel("040 MAG");
    expectLabel("6100 ft MSL");
    tick();
    require(data["sim/joystick/yoke_roll_ratio"].scalar > 0 &&
            data["sim/joystick/yoke_pitch_ratio"].scalar > 0, "panel targets did not steer the yoke");

    inFms = true;
    invoke("levelpilot/flight/toggle_gps");
    expectLabel("FIRST");
    destination = 1;
    for (int i = 0; i < 10; ++i) tick();
    expectLabel("SECOND");
    inFms = false;
    for (int i = 0; i < 10; ++i) tick();
    expectLabel("GPS leg unavailable");
    assertOverrides(true, true);

    data[axes].floats[0] = 0.85f;
    for (int i = 0; i < 5; ++i) tick();
    expectLabel("Manual yoke input");
    assertOverrides(false, false);
    data[axes].floats[0] = 0.5f;

    invoke("levelpilot/flight/engage");
    tick();
    data[axes].floats[1] = 0.9f;
    for (int i = 0; i < 5; ++i) tick();
    expectLabel("Manual throttle input");
    assertOverrides(false, false);
    data[axes].floats[1] = 0.6f;

    invoke("levelpilot/flight/engage");
    invoke("sim/autopilot/servos_off_any");
    assertOverrides(false, false);
    invoke("levelpilot/flight/engage");
    tick();
    set("sim/time/paused", 1);
    tick();
    expectLabel("Simulator paused");
    assertOverrides(false, false);
    set("sim/time/paused", 0);
    tick();
    assertOverrides(false, false);

    click(50, 260);
    expectLabel("MANUAL");
    set(throttleFlag, 1);
    invoke("levelpilot/flight/engage");
    assertOverrides(true, true);
    const int priorThrottleWrites = throttleWrites;
    tick();
    require(throttleWrites == priorThrottleWrites, "manual throttle was written");
    XPluginReceiveMessage(XPLM_PLUGIN_XPLANE, XPLM_MSG_PLANE_UNLOADED, nullptr);
    assertOverrides(false, true);
    set(throttleFlag, 0);

    invoke("levelpilot/flight/engage");
    tick();
    tick(0.6f);
    assertOverrides(false, false);
    expectLabel("Flight loop interrupted");
    invoke("levelpilot/flight/engage");
    XPluginDisable();
    assertOverrides(false, false);
    require(!scheduled && !window.visible, "disable left UI or controller scheduled");
    XPluginStop();
    require(loop.callbackFunc == nullptr && window.drawWindowFunc == nullptr, "resources leaked on stop");
    require(handlers.at("levelpilot/flight/disconnect").callback == nullptr, "disconnect handler leaked");
    std::cout << "XPLM lifecycle, panel, GPS and override handoff passed\n";
}
