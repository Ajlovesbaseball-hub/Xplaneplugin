#include "controller.hpp"

#include <algorithm>
#include <cmath>
#include <cstdlib>
#include <iostream>
#include <limits>

using namespace levelpilot;

namespace {
constexpr double rad = 0.017453292519943295;

void require(bool condition, const char* message) {
    if (!condition) {
        std::cerr << message << '\n';
        std::exit(EXIT_FAILURE);
    }
}

Flight cruise(bool jet = false) {
    Flight f{};
    f.heading = 355;
    f.trueHeading = 5;
    f.track = 5;
    f.pitch = jet ? 2.5 : 4;
    f.altitude = 5200;
    f.agl = 4000;
    f.ias = jet ? 243 : 104;
    f.tas = f.ias * 0.56;
    f.mach = f.tas / 330;
    f.groundSpeed = f.tas;
    f.latitude = 37.5;
    f.longitude = -122.2;
    return f;
}

void closedLoop(bool jet, int fps) {
    Flight f = cruise(jet);
    const Flight start = f;
    const Limits limits = jet ? Limits{128, 334, 0.80, true} : Limits{61, 154, 0, false};
    const Targets target{25, f.altitude + 500, f.ias + 8};
    Controller controller;
    double throttleActual = 0.54;
    controller.engage(f, {0, 0, throttleActual});
    const double dt = 1.0 / fps;
    double maxBank = 0;
    double maxAltitude = start.altitude;
    for (int frame = 0; frame < fps * 150; ++frame) {
        const auto out = controller.update(f, limits, target, angleError(target.heading, f.heading), true, dt);
        require(std::isfinite(out.controls.pitch) && std::isfinite(out.controls.roll) &&
                std::isfinite(out.controls.throttle), "nonfinite closed-loop command");
        const double liftAngle = start.pitch + std::abs(f.bank) * 0.027;
        f.rollRate += dt * ((jet ? 47.0 : 79.0) * out.controls.roll - 2.4 * f.rollRate);
        f.pitchRate += dt * ((jet ? 37.0 : 71.0) * out.controls.pitch - 2.8 * f.pitchRate -
                              0.18 * (f.pitch - start.pitch));
        f.pitch += dt * f.pitchRate;
        f.bank += dt * f.rollRate;
        f.heading = wrap360(f.heading + dt * 9.80665 * std::tan(f.bank * rad) / (f.tas * rad));
        const double desiredVs = f.tas * std::tan((f.pitch - liftAngle) * rad) / 0.00508;
        f.verticalSpeed += dt * (desiredVs - f.verticalSpeed) / (jet ? 1.1 : 0.55);
        f.altitude += dt * f.verticalSpeed / 60;
        throttleActual += dt * (out.controls.throttle - throttleActual) / (jet ? 3.8 : 0.75);
        f.ias += dt * ((jet ? 13.0 : 19.0) * (throttleActual - 0.54) -
                       0.09 * (f.ias - start.ias) - 0.002 * f.verticalSpeed -
                       0.00035 * f.bank * f.bank);
        f.tas = f.ias * 0.56;
        maxBank = std::max(maxBank, std::abs(f.bank));
        maxAltitude = std::max(maxAltitude, f.altitude);
    }
    std::cout << (jet ? "Transport" : "Light aircraft") << " at " << fps << " Hz"
              << " | altitude error " << f.altitude - target.altitude
              << " ft | heading error " << angleError(target.heading, f.heading)
              << " deg | speed error " << f.ias - target.ias << " kt\n";
    require(std::abs(angleError(target.heading, f.heading)) < 2, "heading did not capture");
    require(std::abs(f.altitude - target.altitude) < 35, "altitude did not capture");
    require(std::abs(f.ias - target.ias) < 2, "airspeed did not capture");
    require(maxBank < 33, "excessive bank in commanded turn");
    require(maxAltitude < target.altitude + 140, "excessive altitude overshoot");
}

void protections() {
    auto f = cruise();
    const Limits l{65, 149, 0.75, false};
    const Targets targets{25, 3800, 104};
    Controller c;
    c.engage(f, {0, 0, 0.5});
    f.ias = 62;
    auto out = c.update(f, l, targets, 30, true, 0.035);
    require(out.protection == Protection::Slow && out.targetBank == 0 &&
            out.targetPitch < f.pitch && out.controls.throttle > 0.5, "low speed response");
    f.ias = 66;
    require(c.update(f, l, targets, 30, true, 0.035).protection == Protection::Slow,
            "low speed hysteresis");
    f.ias = 104;
    f.mach = 0.77;
    out = c.update(f, l, targets, -90, true, 0.035);
    require(out.protection == Protection::Fast && out.targetPitch > f.pitch &&
            std::abs(out.targetBank) <= 12, "Mach protection response");
    f.agl = 520;
    f.mach = 0.3;
    out = c.update(f, l, targets, 5, false, 0.035);
    require(out.protection == Protection::LowHeight && out.targetVerticalSpeed == 0, "AGL protection response");
    f.stallWarning = true;
    require(c.update(f, l, targets, 0, false, 0.035).protection == Protection::Slow,
            "stall warning response");
    f.pitchRate = std::numeric_limits<double>::quiet_NaN();
    require(!validFlight(f), "nonfinite sensor rejection");
}

void navigation() {
    require(angleError(2, 358) == 4 && angleError(358, 2) == -4, "heading north crossing");
    auto leg = guideLeg({0, 179}, {0, -179}, {0, 179.5}, 90);
    require(std::abs(angleError(90, leg.course)) < 1 &&
            leg.distanceNm > 89 && leg.distanceNm < 91, "antimeridian crossing");
    const auto northOfLeg = guideLeg({0, 0}, {0, 2}, {0.1, 1}, 85);
    const auto southOfLeg = guideLeg({0, 0}, {0, 2}, {-0.1, 1}, 85);
    require(northOfLeg.course > 90 && southOfLeg.course < 90, "intercept from both sides");
    leg = guideLeg({0, 0}, {0, 1}, {0, 1.02}, 75);
    require(leg.alongNm > leg.legLengthNm, "passed waypoint detection");
}
}  // namespace

int main() {
    navigation();
    protections();
    for (int fps : {20, 30, 60, 120}) {
        closedLoop(false, fps);
        closedLoop(true, fps);
    }
}
