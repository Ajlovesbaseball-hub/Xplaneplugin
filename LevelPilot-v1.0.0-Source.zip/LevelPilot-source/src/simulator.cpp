#include "simulator.hpp"

#include "XPLMNavigation.h"
#include "XPLMUtilities.h"

#include <algorithm>
#include <cmath>
#include <limits>

namespace levelpilot {
namespace {
constexpr double feetPerMeter = 3.280839895013123;

struct DataRefSpec {
    const char* name;
    XPLMDataTypeID type;
    bool required{};
    bool writable{};
};

bool throttleAxis(int assignment) {
    return assignment == 4 || assignment == 38 || (assignment >= 20 && assignment <= 23) ||
           (assignment >= 53 && assignment <= 56);
}

bool checkSpeed(double speed, double min, double max) {
    return std::isfinite(speed) && speed >= min && speed <= max;
}

double surfaceMagnitude(XPLMDataRef dataref) {
    if (!dataref) return 0;
    std::array<float, 128> deflections{};
    const int count = XPLMGetDatavf(dataref, deflections.data(), 0, static_cast<int>(deflections.size()));
    double maximum = 0;
    for (int i = 0; i < count; ++i) {
        if (std::isfinite(deflections[i])) {
            maximum = std::max(maximum, std::abs(static_cast<double>(deflections[i])));
        }
    }
    return maximum;
}
}  // namespace

XPLMDataRef Simulator::ref(Ref id) const { return refs_[static_cast<unsigned>(id)]; }
float Simulator::number(Ref id) const { return ref(id) ? XPLMGetDataf(ref(id)) : 0.0f; }
int Simulator::integer(Ref id) const { return ref(id) ? XPLMGetDatai(ref(id)) : 0; }
double Simulator::precise(Ref id) const { return ref(id) ? XPLMGetDatad(ref(id)) : 0.0; }

const char* Simulator::bind() {
    constexpr DataRefSpec specs[]{
        {"sim/flightmodel/position/mag_psi", xplmType_Float, true},
        {"sim/flightmodel/position/true_psi", xplmType_Float, true},
        {"sim/cockpit2/gauges/indicators/ground_track_mag_pilot", xplmType_Float, true},
        {"sim/flightmodel/position/theta", xplmType_Float, true},
        {"sim/flightmodel/position/phi", xplmType_Float, true},
        {"sim/flightmodel/position/Q", xplmType_Float, true},
        {"sim/flightmodel/position/P", xplmType_Float, true},
        {"sim/flightmodel/position/elevation", xplmType_Double, true},
        {"sim/flightmodel/position/y_agl", xplmType_Float, true},
        {"sim/flightmodel/position/vh_ind_fpm", xplmType_Float, true},
        {"sim/flightmodel/position/indicated_airspeed", xplmType_Float, true},
        {"sim/flightmodel/position/true_airspeed", xplmType_Float, true},
        {"sim/flightmodel/position/groundspeed", xplmType_Float, true},
        {"sim/flightmodel/misc/machno", xplmType_Float, true},
        {"sim/flightmodel/position/latitude", xplmType_Double, true},
        {"sim/flightmodel/position/longitude", xplmType_Double, true},
        {"sim/cockpit2/annunciators/stall_warning", xplmType_Int},
        {"sim/flightmodel/failures/onground_any", xplmType_Int, true},
        {"sim/time/paused", xplmType_Int, true},
        {"sim/time/is_in_replay", xplmType_Int, true},
        {"sim/time/sim_speed", xplmType_Int, true},
        {"sim/time/ground_speed", xplmType_Int},
        {"sim/cockpit2/autopilot/servos_on", xplmType_Int, true},
        {"sim/cockpit2/autopilot/flight_director_mode", xplmType_Int},
        {"sim/cockpit2/autopilot/flight_director2_mode", xplmType_Int},
        {"sim/cockpit2/autopilot/autothrottle_enabled", xplmType_Int},
        {"sim/operation/override/override_joystick", xplmType_Int, true},
        {"sim/operation/override/override_joystick_pitch", xplmType_Int, true, true},
        {"sim/operation/override/override_joystick_roll", xplmType_Int, true, true},
        {"sim/operation/override/override_throttles", xplmType_Int, false, true},
        {"sim/operation/override/override_flightcontrol", xplmType_Int},
        {"sim/operation/override/override_control_surfaces", xplmType_Int},
        {"sim/operation/override/override_planepath", xplmType_IntArray},
        {"sim/joystick/yoke_pitch_ratio", xplmType_Float, true, true},
        {"sim/joystick/yoke_roll_ratio", xplmType_Float, true, true},
        {"sim/flightmodel/engine/ENGN_thro_use", xplmType_FloatArray, false, true},
        {"sim/aircraft/engine/acf_num_engines", xplmType_Int},
        {"sim/flightmodel/engine/ENGN_running", xplmType_IntArray},
        {"sim/aircraft/prop/acf_en_type", xplmType_IntArray},
        {"sim/aircraft/view/acf_Vs", xplmType_Float},
        {"sim/aircraft/view/acf_Vne", xplmType_Float},
        {"sim/aircraft/view/acf_Mmo", xplmType_Float},
        {"sim/cockpit2/controls/flap_system_deploy_ratio", xplmType_Float},
        {"sim/aircraft/view/acf_Vfe", xplmType_Float},
        {"sim/joystick/joystick_axis_values", xplmType_FloatArray},
        {"sim/joystick/joystick_axis_assignments", xplmType_IntArray},
        {"sim/flightmodel2/wing/elevator1_deg", xplmType_FloatArray},
        {"sim/flightmodel2/wing/elevator2_deg", xplmType_FloatArray},
        {"sim/flightmodel2/wing/aileron1_deg", xplmType_FloatArray},
        {"sim/flightmodel2/wing/aileron2_deg", xplmType_FloatArray},
        {"sim/cockpit2/autopilot/heading_dial_deg_mag_pilot", xplmType_Float},
        {"sim/cockpit2/autopilot/altitude_dial_ft", xplmType_Float},
        {"sim/cockpit2/autopilot/airspeed_dial_kts_mach", xplmType_Float},
        {"sim/cockpit2/autopilot/airspeed_is_mach", xplmType_Int},
        {"sim/cockpit2/gauges/indicators/altitude_ft_pilot", xplmType_Float},
    };
    static_assert(sizeof(specs) / sizeof(*specs) == static_cast<unsigned>(Ref::Count));
    const char* missing = nullptr;
    for (unsigned i = 0; i < refs_.size(); ++i) {
        const auto& spec = specs[i];
        auto handle = XPLMFindDataRef(spec.name);
        if (handle && (!(XPLMGetDataRefTypes(handle) & spec.type) ||
                       (spec.writable && !XPLMCanWriteDataRef(handle)))) {
            handle = nullptr;
        }
        refs_[i] = handle;
        if (!handle && spec.required) {
            if (!missing) missing = spec.name;
            XPLMDebugString("[LevelPilot] Required dataref unavailable: ");
            XPLMDebugString(spec.name);
            XPLMDebugString("\n");
        }
    }
    return missing;
}

Flight Simulator::flight() const {
    Flight f{};
    f.heading = number(Ref::Heading);
    f.trueHeading = number(Ref::TrueHeading);
    const double variation = angleError(f.trueHeading, f.heading);
    f.track = wrap360(number(Ref::TrackMag) + variation);
    f.pitch = number(Ref::Pitch);
    f.bank = number(Ref::Bank);
    f.pitchRate = number(Ref::PitchRate);
    f.rollRate = number(Ref::RollRate);
    f.altitude = precise(Ref::Altitude) * feetPerMeter;
    f.agl = number(Ref::Agl) * feetPerMeter;
    f.verticalSpeed = number(Ref::VerticalSpeed);
    f.ias = number(Ref::Ias);
    f.tas = number(Ref::Tas);
    f.mach = number(Ref::Mach);
    f.latitude = precise(Ref::Lat);
    f.longitude = precise(Ref::Lon);
    f.groundSpeed = number(Ref::GroundSpeed);
    f.stallWarning = integer(Ref::StallWarning) != 0;
    return f;
}

Limits Simulator::limits() const {
    int engineType = -1;
    if (ref(Ref::EngineType)) XPLMGetDatavi(ref(Ref::EngineType), &engineType, 0, 1);
    const double vs = number(Ref::Vs);
    const double redline = number(Ref::Vne);
    const double mmo = number(Ref::Mmo);
    const bool transport = engineType == 5 || engineType == 7 ||
                           (checkSpeed(redline, 250, 700) && checkSpeed(mmo, 0.5, 1.25));
    double maximum = checkSpeed(redline, 65, 700) ? redline * 0.97 : (transport ? 320 : 155);
    const double vfe = number(Ref::Vfe);
    if (number(Ref::Flaps) > 0.65 && checkSpeed(vfe, 45, 450)) {
        maximum = std::min(maximum, vfe * 0.99);
    }
    const double fallbackVs = transport ? 96 : 48;
    const double minimum = std::max(50.0, (checkSpeed(vs, 22, 250) ? vs : fallbackVs) * 1.28);
    return {minimum, maximum, checkSpeed(mmo, 0.45, 1.5) ? mmo - 0.02 : 0.0, transport};
}

Surfaces Simulator::surfaces() const {
    return {std::max(surfaceMagnitude(ref(Ref::Elevator1)), surfaceMagnitude(ref(Ref::Elevator2))),
            std::max(surfaceMagnitude(ref(Ref::Aileron1)), surfaceMagnitude(ref(Ref::Aileron2))),
            ref(Ref::Elevator1) && ref(Ref::Aileron1)};
}

bool Simulator::panelTargets(const Flight& f, const Limits& bounds, Targets& targets) const {
    if (!ref(Ref::PanelHeading) || !ref(Ref::PanelAltitude)) return false;
    const double heading = number(Ref::PanelHeading);
    const double altitude = number(Ref::PanelAltitude);
    if (!checkSpeed(heading, -360, 360) || !checkSpeed(altitude, -1000, 60000)) return false;
    targets.heading = wrap360(heading);
    const double offset = ref(Ref::IndicatedAltitude) ? f.altitude - number(Ref::IndicatedAltitude) : 0;
    targets.altitude = std::clamp(altitude + (std::abs(offset) < 2500 ? offset : 0),
                                  -1000.0, 60000.0);
    const double ias = number(Ref::PanelIas);
    targets.ias = integer(Ref::PanelMachMode) == 0 && checkSpeed(ias, bounds.minIas, bounds.maxIas)
        ? ias : std::clamp(f.ias, bounds.minIas, bounds.maxIas);
    return true;
}

bool Simulator::waypoint(Waypoint& point) const {
    const int count = XPLMCountFMSEntries();
    const int index = XPLMGetDestinationFMSEntry();
    if (index < 0 || index >= count) return false;
    XPLMNavType type = xplm_Nav_Unknown;
    float lat = std::numeric_limits<float>::quiet_NaN();
    float lon = lat;
    point.name[0] = '\0';
    XPLMGetFMSEntryInfo(index, &type, point.name, nullptr, nullptr, &lat, &lon);
    point.name[sizeof(point.name) - 1] = '\0';
    if (type == xplm_Nav_Unknown || !checkSpeed(lat, -90, 90) || !checkSpeed(lon, -180, 180)) {
        return false;
    }
    point.position = {lat, lon};
    point.index = index;
    return true;
}

bool Simulator::enginesRunning(int count) const {
    if (!ref(Ref::Running) || count < 1 || count > static_cast<int>(originalThrottle_.size())) return false;
    std::array<int, 16> running{};
    if (XPLMGetDatavi(ref(Ref::Running), running.data(), 0, count) != count) return false;
    return std::all_of(running.begin(), running.begin() + count, [](int value) { return value != 0; });
}

const char* Simulator::interlock(bool active, bool throttle) const {
    if (integer(Ref::Replay)) return "Replay mode";
    if (integer(Ref::Paused)) return "Simulator paused";
    if (integer(Ref::SimSpeed) > 1 || integer(Ref::GroundMultiplier) > 1) {
        return "Set simulation speed to 1x";
    }
    if (integer(Ref::Ground)) return "Aircraft on ground";
    if (integer(Ref::Servos) || integer(Ref::PilotFd) >= 2 || integer(Ref::CopilotFd) >= 2) {
        return "Aircraft autopilot is on";
    }
    if (throttle && integer(Ref::AutoThrottle) > 0) return "Aircraft autothrottle is on";

    int pathOverride = 0;
    if (ref(Ref::PathOverride)) XPLMGetDatavi(ref(Ref::PathOverride), &pathOverride, 0, 1);
    if (integer(Ref::JoystickOverride) || integer(Ref::FlightControlOverride) ||
        integer(Ref::SurfaceOverride) || pathOverride) {
        return "Another add-on controls flight";
    }
    if (integer(Ref::PitchOverride) != (active ? 1 : 0) ||
        integer(Ref::RollOverride) != (active ? 1 : 0) ||
        (throttle && integer(Ref::ThrottleOverride) != (active ? 1 : 0))) {
        return "Control override conflict";
    }
    if (throttle) {
        if (!ref(Ref::ThrottleOverride) || !ref(Ref::ThrottleUse)) return "Throttle datarefs unavailable";
        const int count = integer(Ref::EngineCount);
        if ((active && count != engineCount_) || !enginesRunning(count)) return "Engine unavailable";
    }
    return nullptr;
}

void Simulator::captureHardware() {
    axisCount_ = 0;
    hardwareSeconds_ = 0;
    if (ref(Ref::Axes) && ref(Ref::AxisAssignments)) {
        const int maximum = static_cast<int>(assignments_.size());
        const int assignments = XPLMGetDatavi(ref(Ref::AxisAssignments), assignments_.data(), 0, maximum);
        const int values = XPLMGetDatavf(ref(Ref::Axes), axisBaseline_.data(), 0, maximum);
        axisCount_ = std::clamp(std::min(assignments, values), 0, maximum);
    }
}

const char* Simulator::begin(bool throttle, Controls& initial) {
    if (const char* reason = interlock(false, throttle)) return reason;
    const double pitch = number(Ref::YokePitch);
    const double roll = number(Ref::YokeRoll);
    if (!checkSpeed(pitch, -0.75, 0.75) || !checkSpeed(roll, -0.75, 0.75)) {
        return "Center the yoke before engaging";
    }
    initial = {pitch, roll, 0};
    if (throttle) {
        engineCount_ = integer(Ref::EngineCount);
        if (XPLMGetDatavf(ref(Ref::ThrottleUse), originalThrottle_.data(), 0, engineCount_) != engineCount_) {
            return "Cannot read the engine throttles";
        }
        for (int i = 0; i < engineCount_; ++i) {
            if (!checkSpeed(originalThrottle_[i], 0, 1)) return "Throttle outside forward range";
            initial.throttle += static_cast<double>(originalThrottle_[i]) / engineCount_;
        }
        throttleStart_ = initial.throttle;
        throttleBlend_ = 0;
    }
    captureHardware();
    XPLMSetDatai(ref(Ref::PitchOverride), 1);
    XPLMSetDatai(ref(Ref::RollOverride), 1);
    ownsYoke_ = true;
    if (throttle) {
        XPLMSetDatai(ref(Ref::ThrottleOverride), 1);
        ownsThrottle_ = true;
    }
    if (const char* reason = interlock(true, throttle)) {
        release();
        return reason;
    }
    return nullptr;
}

const char* Simulator::hardwareTakeover(double dt) {
    if (axisCount_ == 0) return nullptr;
    std::array<float, 500> values{};
    const int count = XPLMGetDatavf(ref(Ref::Axes), values.data(), 0, axisCount_);
    const char* reason = nullptr;
    for (int i = 0; i < count; ++i) {
        const float delta = std::abs(values[i] - axisBaseline_[i]);
        if ((assignments_[i] == 1 || assignments_[i] == 2) && delta > 0.22f) {
            reason = "Manual yoke input";
            break;
        }
        if (ownsThrottle_ && throttleAxis(assignments_[i]) && delta > 0.16f) {
            reason = "Manual throttle input";
            break;
        }
    }
    hardwareSeconds_ = reason ? hardwareSeconds_ + dt : 0;
    return hardwareSeconds_ >= 0.12 ? reason : nullptr;
}

void Simulator::apply(Controls controls, double dt) {
    XPLMSetDataf(ref(Ref::YokePitch), static_cast<float>(controls.pitch));
    XPLMSetDataf(ref(Ref::YokeRoll), static_cast<float>(controls.roll));
    if (ownsThrottle_) {
        throttleBlend_ = std::min(1.0, throttleBlend_ + dt * 0.5);
        std::array<float, 16> demand{};
        for (int i = 0; i < engineCount_; ++i) {
            const double offset = (originalThrottle_[i] - throttleStart_) * (1.0 - throttleBlend_);
            demand[i] = static_cast<float>(std::clamp(controls.throttle + offset, 0.0, 1.0));
        }
        XPLMSetDatavf(ref(Ref::ThrottleUse), demand.data(), 0, engineCount_);
    }
}

void Simulator::release() {
    if (ownsThrottle_ && integer(Ref::ThrottleOverride) == 1) XPLMSetDatai(ref(Ref::ThrottleOverride), 0);
    if (ownsYoke_) {
        if (integer(Ref::PitchOverride) == 1) XPLMSetDatai(ref(Ref::PitchOverride), 0);
        if (integer(Ref::RollOverride) == 1) XPLMSetDatai(ref(Ref::RollOverride), 0);
    }
    ownsThrottle_ = false;
    ownsYoke_ = false;
}

}  // namespace levelpilot
