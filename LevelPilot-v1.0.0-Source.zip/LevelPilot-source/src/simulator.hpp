#pragma once

#include "controller.hpp"
#include "XPLMDataAccess.h"

#include <array>

namespace levelpilot {

struct Surfaces {
    double elevator{};
    double aileron{};
    bool available{};
};

struct Waypoint {
    Position position{};
    int index{-1};
    char name[256]{};
};

class Simulator {
public:
    const char* bind();
    Flight flight() const;
    Limits limits() const;
    Surfaces surfaces() const;
    bool panelTargets(const Flight& f, const Limits& limits, Targets& targets) const;
    bool waypoint(Waypoint& point) const;

    const char* interlock(bool active, bool throttle) const;
    const char* begin(bool throttle, Controls& initial);
    const char* hardwareTakeover(double dt);
    void apply(Controls controls, double dt);
    void release();

private:
    enum class Ref {
        Heading, TrueHeading, TrackMag, Pitch, Bank, PitchRate, RollRate, Altitude, Agl,
        VerticalSpeed, Ias, Tas, GroundSpeed, Mach, Lat, Lon, StallWarning, Ground, Paused,
        Replay, SimSpeed, GroundMultiplier, Servos, PilotFd, CopilotFd, AutoThrottle,
        JoystickOverride, PitchOverride, RollOverride, ThrottleOverride, FlightControlOverride,
        SurfaceOverride, PathOverride, YokePitch, YokeRoll, ThrottleUse, EngineCount, Running,
        EngineType, Vs, Vne, Mmo, Flaps, Vfe, Axes, AxisAssignments, Elevator1, Elevator2,
        Aileron1, Aileron2, PanelHeading, PanelAltitude, PanelIas, PanelMachMode, IndicatedAltitude, Count
    };

    XPLMDataRef ref(Ref id) const;
    float number(Ref id) const;
    int integer(Ref id) const;
    double precise(Ref id) const;
    bool enginesRunning(int count) const;
    void captureHardware();

    std::array<XPLMDataRef, static_cast<unsigned>(Ref::Count)> refs_{};
    bool ownsYoke_{};
    bool ownsThrottle_{};
    int engineCount_{};
    std::array<float, 16> originalThrottle_{};
    double throttleStart_{};
    double throttleBlend_{};
    std::array<int, 500> assignments_{};
    std::array<float, 500> axisBaseline_{};
    int axisCount_{};
    double hardwareSeconds_{};
};

}  // namespace levelpilot
