#include "controller.hpp"
#include "simulator.hpp"

#include "XPLMDisplay.h"
#include "XPLMGraphics.h"
#include "XPLMMenus.h"
#include "XPLMPlugin.h"
#include "XPLMProcessing.h"
#include "XPLMUtilities.h"

#include <algorithm>
#include <cmath>
#include <cstdio>
#include <cstring>

namespace {
using namespace levelpilot;

constexpr int windowWidth = 438;
constexpr int windowHeight = 382;
constexpr double engageHeight = 750;
constexpr double releaseHeight = 350;

enum class Action {
    Window, Engage, Disconnect, Capture, Panel, Gps, Throttle, HdgDown, HdgUp,
    AltDown, AltUp, SpeedDown, SpeedUp
};

struct Command {
    const char* name;
    const char* label;
    Action action;
    bool stock{};
    XPLMCommandRef handle{};
};

Command commands[]{
    {"levelpilot/flight/toggle_panel", "LevelPilot: toggle flight panel", Action::Window},
    {"levelpilot/flight/engage", "LevelPilot: engage and capture current flight", Action::Engage},
    {"levelpilot/flight/disconnect", "LevelPilot: disconnect and return control", Action::Disconnect},
    {"levelpilot/flight/capture", "LevelPilot: capture current heading, altitude and IAS", Action::Capture},
    {"levelpilot/flight/panel_targets", "LevelPilot: copy aircraft autopilot targets", Action::Panel},
    {"levelpilot/flight/toggle_gps", "LevelPilot: switch between GPS and heading", Action::Gps},
    {"sim/autopilot/servos_off_any", nullptr, Action::Disconnect, true},
    {"sim/autopilot/servos_off", nullptr, Action::Disconnect, true},
    {"sim/autopilot/disconnect", nullptr, Action::Disconnect, true},
};

struct Session {
    Simulator sim;
    Controller controller;
    XPLMMenuID menu{};
    XPLMFlightLoopID loop{};
    XPLMWindowID window{};
    int menuIndex{-1};
    bool enabled{};
    bool ready{};
    bool hasSample{};
    bool active{};
    bool manageThrottle{true};
    bool gps{};
    bool firstFrame{};
    bool legValid{};
    double gpsSeconds{};
    double legEndSeconds{};
    double limitsSeconds{};
    double surfaceSeconds{};
    double pitchNoResponse{};
    double rollNoResponse{};
    Position legOrigin{};
    Waypoint leg{};
    LegGuidance guidance{};
    Flight flight{};
    Limits limits{};
    Targets targets{};
    Output output{};
    Surfaces surfaces{};
    const char* status{"Ready to engage in flight"};
};

Session session;
Action menuActions[]{Action::Window, Action::Engage, Action::Disconnect, Action::Capture,
                     Action::Panel, Action::Gps};

void status(const char* text, bool log = false) {
    session.status = text;
    if (log) {
        char line[160]{};
        std::snprintf(line, sizeof(line), "[LevelPilot] %s\n", text);
        XPLMDebugString(line);
    }
}

void disconnect(const char* reason) {
    if (session.active) session.sim.release();
    if (session.active) status(reason, true);
    session.active = false;
    session.gps = false;
    session.legValid = false;
}

bool goodLimits(const Limits& bounds) {
    return std::isfinite(bounds.minIas) && std::isfinite(bounds.maxIas) &&
           bounds.maxIas - bounds.minIas >= 8;
}

bool sample() {
    session.flight = session.sim.flight();
    session.hasSample = validFlight(session.flight);
    return session.hasSample;
}

void capture() {
    const auto& f = session.flight;
    const auto& l = session.limits;
    session.targets = {wrap360(f.heading), std::clamp(f.altitude, -1000.0, 60000.0),
                       std::clamp(f.ias, l.minIas, l.maxIas)};
    session.gps = false;
    session.legValid = false;
}

void engage() {
    if (session.active) return;
    if (!session.ready) {
        status("Required datarefs unavailable. See Log.txt");
        return;
    }
    if (const char* reason = session.sim.interlock(false, session.manageThrottle)) {
        status(reason);
        return;
    }
    if (!sample()) {
        status("Invalid flight telemetry");
        return;
    }
    session.limits = session.sim.limits();
    const auto& f = session.flight;
    const auto& l = session.limits;
    if (!goodLimits(l)) {
        status("Aircraft speed limits are incompatible");
        return;
    }
    if (f.agl < engageHeight) {
        status("Climb above 750 ft AGL to engage");
        return;
    }
    if (f.ias < l.minIas + 4 || f.ias > l.maxIas - 3 || f.stallWarning ||
        (l.maxMach > 0 && f.mach > l.maxMach - 0.015)) {
        status("Stabilize airspeed before engaging");
        return;
    }
    if (std::abs(f.bank) > 27 || std::abs(f.pitch) > 16 || f.tas < 18) {
        status("Level the aircraft before engaging");
        return;
    }
    Controls initial{};
    if (const char* reason = session.sim.begin(session.manageThrottle, initial)) {
        status(reason);
        return;
    }
    capture();
    session.controller.engage(f, initial);
    session.output = {};
    session.output.controls = initial;
    session.active = true;
    session.firstFrame = true;
    session.limitsSeconds = 0;
    session.surfaceSeconds = 0;
    session.pitchNoResponse = 0;
    session.rollNoResponse = 0;
    status("Engaged. Current flight targets captured", true);
    XPLMScheduleFlightLoop(session.loop, -1, 1);
}

void fallbackHeading(const char* reason) {
    session.targets.heading = wrap360(session.flight.heading);
    session.gps = false;
    session.legValid = false;
    status(reason, true);
}

void toggleGps() {
    if (session.gps) {
        fallbackHeading("Heading hold captured");
        return;
    }
    Waypoint first{};
    if (!session.sim.waypoint(first)) {
        status("Activate a route in the stock GPS or FMS");
        return;
    }
    const auto& f = session.flight;
    if (f.groundSpeed < 15) {
        status("Ground track unavailable");
        return;
    }
    session.leg = first;
    session.legOrigin = {f.latitude, f.longitude};
    session.gps = true;
    session.legValid = true;
    session.gpsSeconds = 0;
    session.legEndSeconds = 0;
    session.guidance = guideLeg(session.legOrigin, first.position, session.legOrigin, f.groundSpeed);
    status("Following the stock GPS / FMS active leg", true);
}

double lateralError(double dt) {
    auto& s = session;
    if (s.gps) {
        s.gpsSeconds += dt;
        const Position current{s.flight.latitude, s.flight.longitude};
        if (s.gpsSeconds >= 0.20) {
            s.gpsSeconds = 0;
            Waypoint latest{};
            s.legValid = s.sim.waypoint(latest);
            if (s.legValid && (latest.index != s.leg.index ||
                               latest.position.latitude != s.leg.position.latitude ||
                               latest.position.longitude != s.leg.position.longitude)) {
                s.legOrigin = latest.index == s.leg.index + 1 ? s.leg.position : current;
                s.leg = latest;
                s.legEndSeconds = 0;
            }
        }
        if (!s.legValid) {
            fallbackHeading("GPS leg unavailable. Holding heading");
        } else if (s.flight.groundSpeed < 15) {
            fallbackHeading("Ground track unavailable. Holding heading");
        } else {
            const auto next = guideLeg(s.legOrigin, s.leg.position, current, s.flight.groundSpeed);
            const double close = std::clamp(s.flight.groundSpeed * 5 / 1852.0, 0.16, 0.55);
            if (next.distanceNm < close || next.alongNm > next.legLengthNm + close) {
                s.legEndSeconds += dt;
                s.guidance.distanceNm = next.distanceNm;
                if (s.legEndSeconds >= 2.5) {
                    fallbackHeading("GPS leg ended. Holding heading");
                }
            } else {
                s.legEndSeconds = 0;
                s.guidance = next;
            }
            if (s.gps) return angleError(s.guidance.course, s.flight.track);
        }
    }
    return angleError(s.targets.heading, s.flight.heading);
}

const char* lostControlResponse(double period) {
    auto& s = session;
    const auto& output = s.output;
    const bool pitchBlocked = s.surfaces.available && s.surfaces.elevator < 0.8 &&
        std::abs(output.controls.pitch) > 0.48 && std::abs(s.flight.pitchRate) < 1.5 &&
        std::abs(output.targetPitch - s.flight.pitch) > 7;
    const bool rollBlocked = s.surfaces.available && s.surfaces.aileron < 0.8 &&
        std::abs(output.controls.roll) > 0.48 && std::abs(s.flight.rollRate) < 2.0 &&
        std::abs(output.targetBank - s.flight.bank) > 13;
    s.pitchNoResponse = pitchBlocked ? s.pitchNoResponse + period : 0;
    s.rollNoResponse = rollBlocked ? s.rollNoResponse + period : 0;
    if (s.pitchNoResponse >= 3.0) return "No elevator response";
    if (s.rollNoResponse >= 3.0) return "No aileron response";
    return nullptr;
}

float flightLoop(float elapsed, float, int, void*) {
    auto& s = session;
    if (!s.enabled || !s.ready) return 0;
    if (!sample()) {
        disconnect("Invalid flight telemetry. Manual control");
        return 0.15f;
    }
    if (!s.active) {
        if (s.window && XPLMGetWindowIsVisible(s.window)) {
            s.surfaces = s.sim.surfaces();
        }
        return 0.15f;
    }
    if (const char* reason = s.sim.interlock(true, s.manageThrottle)) {
        disconnect(reason);
        return 0.15f;
    }
    const auto& f = s.flight;
    if (f.agl < releaseHeight || std::abs(f.bank) > 62 || std::abs(f.pitch) > 32 ||
        f.ias < 32 || f.tas < 15) {
        disconnect("Outside assisted flight envelope. Manual control");
        return 0.15f;
    }
    if (!s.firstFrame && (!std::isfinite(elapsed) || elapsed <= 0 || elapsed > 0.35f)) {
        disconnect("Flight loop interrupted. Manual control");
        return 0.15f;
    }
    const double dt = s.firstFrame ? 0.016 : std::min<double>(elapsed, 0.1);
    s.firstFrame = false;
    if (const char* reason = s.sim.hardwareTakeover(dt)) {
        disconnect(reason);
        return 0.15f;
    }
    s.limitsSeconds += dt;
    if (s.limitsSeconds >= 0.25) {
        s.limitsSeconds = 0;
        s.limits = s.sim.limits();
        if (!goodLimits(s.limits)) {
            disconnect("Aircraft speed limits changed. Manual control");
            return 0.15f;
        }
        s.targets.ias = std::clamp(s.targets.ias, s.limits.minIas, s.limits.maxIas);
    }
    const double error = lateralError(dt);
    s.output = s.controller.update(f, s.limits, s.targets, error,
                                   s.manageThrottle, dt);
    s.surfaceSeconds += dt;
    if (s.surfaceSeconds >= 0.12) {
        s.surfaces = s.sim.surfaces();
        if (const char* reason = lostControlResponse(s.surfaceSeconds)) {
            disconnect(reason);
            return 0.15f;
        }
        s.surfaceSeconds = 0;
    }
    s.sim.apply(s.output.controls, dt);
    return -1;
}

struct Button {
    int x, y, width;
    const char* label;
    Action action;
};

constexpr Button buttons[]{
    {16, 57, 198, "ENGAGE / CAPTURE", Action::Engage},
    {224, 57, 198, "DISCONNECT", Action::Disconnect},
    {330, 105, 42, "-", Action::HdgDown}, {380, 105, 42, "+", Action::HdgUp},
    {330, 135, 42, "-", Action::AltDown}, {380, 135, 42, "+", Action::AltUp},
    {330, 165, 42, "-", Action::SpeedDown}, {380, 165, 42, "+", Action::SpeedUp},
    {16, 213, 126, "CAPTURE NOW", Action::Capture},
    {156, 213, 126, "PANEL TARGETS", Action::Panel},
    {296, 213, 126, "GPS ROUTE", Action::Gps},
    {16, 250, 170, "AUTO THROTTLE", Action::Throttle},
};
constexpr int buttonHeight = 24;

void act(Action action);

void drawText(int left, int top, int x, int y, const char* text,
              float r = 0.86f, float g = 0.91f, float b = 0.95f) {
    char buffer[256]{};
    std::snprintf(buffer, sizeof(buffer), "%s", text);
    float color[]{r, g, b};
    XPLMDrawString(color, left + x, top - y, buffer, nullptr, xplmFont_Proportional);
}

const char* protectionLabel(Protection protection) {
    switch (protection) {
        case Protection::Slow: return "LOW SPEED / STALL ASSIST";
        case Protection::Fast: return "OVERSPEED ASSIST";
        case Protection::LowHeight: return "DESCENT LIMITED BY AGL";
        case Protection::None: return "AIRBORNE FLIGHT ASSIST";
    }
    return "";
}

bool buttonEnabled(Action action) {
    switch (action) {
        case Action::Engage: return session.ready && !session.active;
        case Action::Throttle: return !session.active;
        case Action::Window: return true;
        case Action::SpeedDown:
        case Action::SpeedUp: return session.active && session.manageThrottle;
        default: return session.active;
    }
}

void drawPanel(XPLMWindowID window, void*) {
    int left, top, right, bottom;
    XPLMGetWindowGeometry(window, &left, &top, &right, &bottom);
    const auto& s = session;
    drawText(left, top, 16, 26, s.active ? "ENGAGED" : "STANDBY",
             s.active ? 0.44f : 0.73f, s.active ? 0.95f : 0.80f, s.active ? 0.78f : 0.85f);
    drawText(left, top, 123, 26, s.active ? protectionLabel(s.output.protection) : "X-PLANE 12");
    drawText(left, top, 16, 44, s.status, 0.73f, 0.80f, 0.85f);
    for (const auto& button : buttons) {
        const int x = left + button.x;
        const int y = top - button.y;
        const bool enabled = buttonEnabled(button.action);
        XPLMDrawTranslucentDarkBox(x, y, x + button.width, y - buttonHeight);
        drawText(left, top, button.x + 9, button.y + 16, button.label,
                 enabled ? 0.84f : 0.57f, enabled ? 0.94f : 0.65f, enabled ? 1.0f : 0.70f);
    }

    char line[148]{};
    const auto& f = s.flight;
    const auto& t = s.targets;
    if (s.active) {
        if (s.gps) {
            std::snprintf(line, sizeof(line), "GPS   %-14.14s  %5.1f NM", s.leg.name, s.guidance.distanceNm);
        } else {
            const auto target = static_cast<int>(std::lround(t.heading)) % 360;
            const auto actual = static_cast<int>(std::lround(wrap360(f.heading))) % 360;
            std::snprintf(line, sizeof(line), "HDG    %03d MAG    /    %03d now", target, actual);
        }
        drawText(left, top, 16, 121, line);
        std::snprintf(line, sizeof(line), "ALT     %5.0f ft MSL  /  %5.0f now", t.altitude, f.altitude);
        drawText(left, top, 16, 151, line);
        if (s.manageThrottle) {
            std::snprintf(line, sizeof(line), "IAS     %5.0f kt   /   %5.0f now", t.ias, f.ias);
        } else {
            std::snprintf(line, sizeof(line), "IAS     %5.0f kt   /   manual throttle", f.ias);
        }
        drawText(left, top, 16, 181, line);
    } else {
        drawText(left, top, 16, 121, "HEADING  /  Captures on engage");
        drawText(left, top, 16, 151, "ALTITUDE  /  Captures on engage");
        drawText(left, top, 16, 181, "AIRSPEED  /  Captures on engage");
    }
    drawText(left, top, 204, 266, s.manageThrottle ? "ON" : "MANUAL",
             0.53f, 0.88f, 0.94f);

    if (s.hasSample) {
        std::snprintf(line, sizeof(line), "AGL %.0f ft    VS %+.0f fpm    Bank %+.1f deg",
                      f.agl, f.verticalSpeed, f.bank);
        drawText(left, top, 16, 301, line);
        if (s.surfaces.available) {
            std::snprintf(line, sizeof(line), "Peak surface deflection    Elevator %.1f / Aileron %.1f deg",
                          s.surfaces.elevator, s.surfaces.aileron);
            drawText(left, top, 16, 322, line, 0.73f, 0.80f, 0.85f);
        }
        if (s.active) {
            const auto& control = s.output.controls;
            if (s.manageThrottle) {
                std::snprintf(line, sizeof(line), "Commands    Pitch %+.0f%%    Roll %+.0f%%    Throttle %.0f%%",
                              control.pitch * 100, control.roll * 100, control.throttle * 100);
            } else {
                std::snprintf(line, sizeof(line), "Commands    Pitch %+.0f%%    Roll %+.0f%%",
                              control.pitch * 100, control.roll * 100);
            }
            drawText(left, top, 16, 343, line, 0.73f, 0.80f, 0.85f);
        }
    }
    drawText(left, top, 16, 366, "Bind LevelPilot: disconnect in X-Plane joystick settings",
             0.73f, 0.80f, 0.85f);
}

int clickPanel(XPLMWindowID window, int x, int y, XPLMMouseStatus phase, void*) {
    if (phase != xplm_MouseDown) return 1;
    int left, top, right, bottom;
    XPLMGetWindowGeometry(window, &left, &top, &right, &bottom);
    x -= left;
    y = top - y;
    for (const auto& button : buttons) {
        if (x >= button.x && x < button.x + button.width &&
            y >= button.y && y < button.y + buttonHeight) {
            if (buttonEnabled(button.action)) act(button.action);
            break;
        }
    }
    return 1;
}

void toggleWindow() {
    auto& s = session;
    if (!s.window) {
        int left, top, right, bottom;
        XPLMGetScreenBoundsGlobal(&left, &top, &right, &bottom);
        XPLMCreateWindow_t params{};
        params.structSize = sizeof(params);
        params.left = left + 42;
        params.top = top - 80;
        params.right = params.left + windowWidth;
        params.bottom = params.top - windowHeight;
        params.visible = 1;
        params.drawWindowFunc = drawPanel;
        params.handleMouseClickFunc = clickPanel;
        params.decorateAsFloatingWindow = xplm_WindowDecorationRoundRectangle;
        params.layer = xplm_WindowLayerFloatingWindows;
        s.window = XPLMCreateWindowEx(&params);
        if (s.window) {
            XPLMSetWindowTitle(s.window, "LevelPilot");
            XPLMSetWindowResizingLimits(s.window, windowWidth, windowHeight, windowWidth, windowHeight);
        }
    } else {
        XPLMSetWindowIsVisible(s.window, !XPLMGetWindowIsVisible(s.window));
        if (XPLMGetWindowIsVisible(s.window)) XPLMBringWindowToFront(s.window);
    }
}

void act(Action action) {
    auto& s = session;
    if (!s.enabled) return;
    if (action == Action::Window) { toggleWindow(); return; }
    if (action == Action::Engage) { engage(); return; }
    if (action == Action::Disconnect) { disconnect("Disconnected. Manual control"); return; }
    if (action == Action::Throttle && !s.active) {
        s.manageThrottle = !s.manageThrottle;
        status(s.manageThrottle ? "Autothrottle will engage with LevelPilot" : "Throttle stays under pilot control");
        return;
    }
    if (!s.active) return;

    switch (action) {
        case Action::Capture:
            capture();
            status("Current flight targets captured");
            break;
        case Action::Panel:
            if (s.sim.panelTargets(s.flight, s.limits, s.targets)) {
                s.gps = false;
                s.legValid = false;
                status("Aircraft panel targets copied");
            } else {
                status("Cockpit heading or altitude unavailable");
            }
            break;
        case Action::Gps:
            toggleGps();
            break;
        case Action::HdgDown:
        case Action::HdgUp:
            if (s.gps) fallbackHeading("Heading hold selected");
            s.targets.heading = wrap360(s.targets.heading + (action == Action::HdgUp ? 5 : -5));
            break;
        case Action::AltDown:
        case Action::AltUp:
            s.targets.altitude = std::clamp(s.targets.altitude + (action == Action::AltUp ? 500 : -500),
                                            -1000.0, 60000.0);
            break;
        case Action::SpeedDown:
        case Action::SpeedUp:
            if (s.manageThrottle) {
                s.targets.ias = std::clamp(s.targets.ias + (action == Action::SpeedUp ? 5 : -5),
                                           s.limits.minIas, s.limits.maxIas);
            }
            break;
        default:
            break;
    }
}

int commandHandler(XPLMCommandRef, XPLMCommandPhase phase, void* refcon) {
    const auto& command = *static_cast<const Command*>(refcon);
    if (phase == xplm_CommandBegin) act(command.action);
    return 1;
}

void menuHandler(void*, void* refcon) {
    act(*static_cast<Action*>(refcon));
}

void cleanUp() {
    auto& s = session;
    s.sim.release();
    s.active = false;
    for (auto& command : commands) {
        if (command.handle) XPLMUnregisterCommandHandler(command.handle, commandHandler, 1, &command);
        command.handle = nullptr;
    }
    if (s.window) XPLMDestroyWindow(s.window);
    if (s.loop) XPLMDestroyFlightLoop(s.loop);
    if (s.menu) XPLMDestroyMenu(s.menu);
    if (s.menuIndex >= 0) XPLMRemoveMenuItem(XPLMFindPluginsMenu(), s.menuIndex);
    s = Session{};
}
}  // namespace

PLUGIN_API int XPluginStart(char* name, char* signature, char* description) {
    std::strcpy(name, "LevelPilot");
    std::strcpy(signature, "org.levelpilot.flightcontrol");
    std::strcpy(description, "Direct yoke and throttle control for airborne flight in X-Plane 12.");
    auto& s = session;
    XPLMCreateFlightLoop_t params{};
    params.structSize = sizeof(params);
    params.phase = xplm_FlightLoop_Phase_BeforeFlightModel;
    params.callbackFunc = flightLoop;
    s.loop = XPLMCreateFlightLoop(&params);
    if (!s.loop) return 0;
    const auto plugins = XPLMFindPluginsMenu();
    s.menuIndex = XPLMAppendMenuItem(plugins, "LevelPilot", nullptr, 0);
    if (s.menuIndex >= 0) s.menu = XPLMCreateMenu("LevelPilot", plugins, s.menuIndex, menuHandler, nullptr);
    if (!s.menu) {
        cleanUp();
        return 0;
    }

    const char* labels[]{"Flight panel", "Engage and capture", "Disconnect", "Capture current flight",
                         "Copy aircraft panel targets", "Toggle GPS route"};
    for (unsigned i = 0; i < sizeof(labels) / sizeof(*labels); ++i) {
        XPLMAppendMenuItem(s.menu, labels[i], &menuActions[i], 0);
    }
    for (auto& command : commands) {
        command.handle = command.stock ? XPLMFindCommand(command.name) :
                                        XPLMCreateCommand(command.name, command.label);
        if (command.handle) XPLMRegisterCommandHandler(command.handle, commandHandler, 1, &command);
    }
    return 1;
}

PLUGIN_API int XPluginEnable() {
    auto& s = session;
    s.enabled = true;
    s.ready = s.sim.bind() == nullptr;
    s.hasSample = false;
    if (s.ready) {
        status("Ready to engage in flight");
        XPLMScheduleFlightLoop(s.loop, -1, 1);
    } else {
        status("Required datarefs unavailable. See Log.txt", true);
    }
    return 1;
}

PLUGIN_API void XPluginDisable() {
    auto& s = session;
    disconnect("Plugin disabled. Manual control");
    s.enabled = false;
    if (s.loop) XPLMScheduleFlightLoop(s.loop, 0, 1);
    if (s.window) XPLMSetWindowIsVisible(s.window, 0);
}

PLUGIN_API void XPluginStop() {
    cleanUp();
}

PLUGIN_API void XPluginReceiveMessage(XPLMPluginID source, int message, void* parameter) {
    if (source != XPLM_PLUGIN_XPLANE) return;
    if (message == XPLM_MSG_PLANE_CRASHED || message == XPLM_MSG_AIRPORT_LOADED ||
        ((message == XPLM_MSG_PLANE_LOADED || message == XPLM_MSG_PLANE_UNLOADED) && !parameter)) {
        disconnect("Flight changed. Manual control");
        session.hasSample = false;
    }
}
