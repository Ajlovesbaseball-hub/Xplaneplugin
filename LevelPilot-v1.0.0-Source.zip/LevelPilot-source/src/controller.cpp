#include "controller.hpp"

#include <algorithm>
#include <cmath>

namespace levelpilot {
namespace {
constexpr double rad = 0.017453292519943295;
constexpr double feetPerMinuteToMps = 0.00508;
constexpr double earthNm = 3440.065;

double lowPass(double old, double value, double dt, double seconds) {
    return old + (value - old) * (dt / (seconds + dt));
}

double slew(double old, double value, double rate, double dt) {
    return old + std::clamp(value - old, -rate * dt, rate * dt);
}

double integrate(double trim, double error, double gain, double fastTerm, double dt,
                 double trimLow, double trimHigh, double outputLow, double outputHigh) {
    const double candidate = std::clamp(trim + error * gain * dt, trimLow, trimHigh);
    if (candidate > trim && fastTerm + candidate > outputHigh) return trim;
    if (candidate < trim && fastTerm + candidate < outputLow) return trim;
    return candidate;
}

double flightPath(const Flight& f, double verticalSpeed) {
    return std::atan2(verticalSpeed * feetPerMinuteToMps, std::max(f.tas, 20.0)) / rad;
}

double angularDistance(Position a, Position b) {
    const double north = (b.latitude - a.latitude) * rad / 2;
    const double east = angleError(b.longitude, a.longitude) * rad / 2;
    const double sinN = std::sin(north);
    const double sinE = std::sin(east);
    const double h = sinN * sinN +
                     std::cos(a.latitude * rad) * std::cos(b.latitude * rad) * sinE * sinE;
    return 2 * std::asin(std::sqrt(std::clamp(h, 0.0, 1.0)));
}

double bearing(Position a, Position b) {
    const double lat1 = a.latitude * rad;
    const double lat2 = b.latitude * rad;
    const double delta = angleError(b.longitude, a.longitude) * rad;
    const double y = std::sin(delta) * std::cos(lat2);
    const double x = std::cos(lat1) * std::sin(lat2) -
                     std::sin(lat1) * std::cos(lat2) * std::cos(delta);
    return std::atan2(y, x);
}

Position pointAlong(Position start, double course, double distance) {
    const double lat1 = start.latitude * rad;
    const double lat = std::asin(std::clamp(std::sin(lat1) * std::cos(distance) +
                      std::cos(lat1) * std::sin(distance) * std::cos(course), -1.0, 1.0));
    const double deltaLon = std::atan2(std::sin(course) * std::sin(distance) * std::cos(lat1),
                                       std::cos(distance) - std::sin(lat1) * std::sin(lat));
    return {lat / rad, angleError(start.longitude + deltaLon / rad, 0)};
}
}  // namespace

double wrap360(double angle) {
    const double wrapped = std::fmod(angle, 360.0);
    return wrapped < 0 ? wrapped + 360.0 : wrapped;
}

double angleError(double target, double current) {
    return wrap360(target - current + 180.0) - 180.0;
}

bool validFlight(const Flight& f) {
    const double fields[]{f.heading, f.trueHeading, f.track, f.pitch, f.bank, f.pitchRate,
                          f.rollRate, f.altitude, f.agl, f.verticalSpeed, f.ias, f.tas,
                          f.mach, f.latitude, f.longitude, f.groundSpeed};
    for (double value : fields) {
        if (!std::isfinite(value)) return false;
    }
    return std::abs(f.pitch) <= 90 && std::abs(f.bank) <= 180 &&
           std::abs(f.latitude) <= 90 && std::abs(f.longitude) <= 180 &&
           f.ias >= 0 && f.ias < 1000 && f.tas >= 0 && f.mach >= 0 &&
           f.groundSpeed >= 0 && std::abs(f.pitchRate) < 720 &&
           std::abs(f.rollRate) < 720 && std::abs(f.verticalSpeed) < 35'000;
}

LegGuidance guideLeg(Position origin, Position destination, Position aircraft, double gs) {
    const double course = bearing(origin, destination);
    const double fromOrigin = angularDistance(origin, aircraft);
    const double relative = bearing(origin, aircraft) - course;
    const double along = std::atan2(std::sin(fromOrigin) * std::cos(relative),
                                    std::cos(fromOrigin));
    const double length = angularDistance(origin, destination);
    const double lookAhead = std::clamp(gs * 32 / 1852.0, 0.45, 4.0) / earthNm;
    const Position aim = pointAlong(origin, course, std::clamp(along + lookAhead, 0.0, length));
    return {wrap360(bearing(aircraft, aim) / rad),
            angularDistance(aircraft, destination) * earthNm, along * earthNm, length * earthNm};
}

void Controller::engage(const Flight& f, Controls initial) {
    output_ = initial;
    pitchTrim_ = std::clamp(initial.pitch, -0.45, 0.45);
    rollTrim_ = std::clamp(initial.roll, -0.30, 0.30);
    throttleTrim_ = std::clamp(initial.throttle, 0.0, 1.0);
    filteredIas_ = f.ias;
    filteredVs_ = f.verticalSpeed;
    filteredAcceleration_ = 0;
    liftAngle_ = std::clamp(f.pitch - flightPath(f, f.verticalSpeed), -3.0, 12.0);
    protection_ = Protection::None;
}

Output Controller::update(const Flight& f, const Limits& l, const Targets& t,
                          double lateralError, bool managesThrottle, double dt) {
    dt = std::clamp(dt, 0.001, 0.1);
    filteredVs_ = lowPass(filteredVs_, f.verticalSpeed, dt, 0.70);
    const double oldIas = filteredIas_;
    filteredIas_ = lowPass(filteredIas_, f.ias, dt, 0.65);
    filteredAcceleration_ = lowPass(filteredAcceleration_, (filteredIas_ - oldIas) / dt,
                                    dt, 1.4);

    const double speedMargin = std::clamp(l.minIas * 0.045, 3.0, 7.0);
    const double slowThreshold = l.minIas + (protection_ == Protection::Slow ? speedMargin : 0);
    const double fastThreshold = l.maxIas - (protection_ == Protection::Fast ? 5.0 : 0.0);
    const double machThreshold = l.maxMach - (protection_ == Protection::Fast ? 0.015 : 0.0);
    if (f.stallWarning || f.ias < slowThreshold) {
        protection_ = Protection::Slow;
    } else if (f.ias > fastThreshold || (l.maxMach > 0 && f.mach > machThreshold)) {
        protection_ = Protection::Fast;
    } else if (f.agl < 650 && t.altitude < f.altitude) {
        protection_ = Protection::LowHeight;
    } else {
        protection_ = Protection::None;
    }

    const double turnRate = std::clamp(lateralError * 0.115, -3.0, 3.0);
    const double bankLimit = l.transport ? 25 : 23;
    double bankTarget = std::clamp(std::atan(turnRate * rad * f.tas / 9.80665) / rad,
                                   -bankLimit, bankLimit);
    const double vsLimit = l.transport ? 1700 : 750;
    double vsTarget = std::clamp((t.altitude - f.altitude) * 4.5, -vsLimit, vsLimit);
    const double softSpeedMargin = std::clamp(l.minIas * 0.13, 7.0, 19.0);
    const double climbFraction = std::clamp((filteredIas_ - l.minIas) / softSpeedMargin, 0.0, 1.0);
    vsTarget = std::min(vsTarget, vsLimit * climbFraction);
    if (protection_ == Protection::LowHeight) vsTarget = 0;

    const double gamma = flightPath(f, filteredVs_);
    if (protection_ != Protection::Slow) {
        liftAngle_ = lowPass(liftAngle_, std::clamp(f.pitch - gamma, -3.0, 12.0), dt, 5.0);
    }
    const double desiredGamma = flightPath(f, vsTarget);
    double pitchTarget = std::clamp(liftAngle_ + desiredGamma +
                                     std::clamp((desiredGamma - gamma) * 0.32, -3.0, 3.0) +
                                     0.0018 * bankTarget * bankTarget, -9.0, 12.0);
    if (protection_ == Protection::Slow) {
        bankTarget = 0;
        pitchTarget = std::min(pitchTarget, liftAngle_ - (f.stallWarning ? 7.0 : 4.0));
    } else if (protection_ == Protection::Fast) {
        bankTarget = std::clamp(bankTarget, -12.0, 12.0);
        pitchTarget = std::max(pitchTarget, std::min(12.0, liftAngle_ + 3.5));
    }

    const double authority = std::clamp(std::pow(std::max(l.minIas, 45.0) /
                                       std::max(filteredIas_, 45.0), 0.85), 0.40, 1.1);
    const double pitchError = pitchTarget - f.pitch;
    const double rollError = bankTarget - f.bank;
    const double pitchFast = authority * (0.085 * pitchError - 0.050 * f.pitchRate);
    const double rollFast = authority * (0.066 * rollError - 0.037 * f.rollRate);
    if (protection_ != Protection::Slow && protection_ != Protection::Fast) {
        pitchTrim_ = integrate(pitchTrim_, pitchError, 0.016, pitchFast, dt,
                               -0.55, 0.55, -0.80, 0.80);
        rollTrim_ = integrate(rollTrim_, rollError, 0.011, rollFast, dt,
                              -0.38, 0.38, -0.80, 0.80);
    }
    output_.pitch = slew(output_.pitch, std::clamp(pitchTrim_ + pitchFast, -0.80, 0.80), 1.30, dt);
    output_.roll = slew(output_.roll, std::clamp(rollTrim_ + rollFast, -0.80, 0.80), 1.50, dt);

    if (managesThrottle) {
        const double targetIas = std::clamp(t.ias, l.minIas, l.maxIas);
        const double speedError = targetIas - filteredIas_;
        const double throttleFast = (l.transport ? 0.010 : 0.020) * speedError -
                                    (l.transport ? 0.070 : 0.105) * filteredAcceleration_ +
                                    (l.transport ? 0.000065 : 0.00013) * vsTarget;
        double demand = throttleTrim_ + throttleFast;
        if (protection_ == Protection::Slow) {
            demand = 1;
        } else if (protection_ == Protection::Fast) {
            demand = 0;
        } else {
            throttleTrim_ = integrate(throttleTrim_, speedError, l.transport ? 0.001 : 0.0022,
                                      throttleFast, dt, 0.0, 1.0, 0.0, 1.0);
            demand = throttleTrim_ + throttleFast;
        }
        output_.throttle = slew(output_.throttle, std::clamp(demand, 0.0, 1.0), 0.24, dt);
    }
    return {output_, bankTarget, pitchTarget, vsTarget, protection_};
}

}  // namespace levelpilot
