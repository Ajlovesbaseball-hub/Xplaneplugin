#pragma once

namespace levelpilot {

struct Flight {
    double heading{};          // Magnetic degrees
    double trueHeading{};
    double track{};            // True ground track
    double pitch{};
    double bank{};
    double pitchRate{};        // Body rates in degrees per second
    double rollRate{};
    double altitude{};         // Feet MSL
    double agl{};              // Feet AGL
    double verticalSpeed{};    // Feet per minute
    double ias{};              // Knots
    double tas{};              // Meters per second
    double mach{};
    double latitude{};
    double longitude{};
    double groundSpeed{};      // Meters per second
    bool stallWarning{};
};

struct Limits {
    double minIas{65};
    double maxIas{150};
    double maxMach{};          // Zero means unavailable
    bool transport{};
};

struct Targets {
    double heading{};
    double altitude{};
    double ias{};
};

struct Controls {
    double pitch{};
    double roll{};
    double throttle{};
};

enum class Protection { None, Slow, Fast, LowHeight };

struct Output {
    Controls controls{};
    double targetBank{};
    double targetPitch{};
    double targetVerticalSpeed{};
    Protection protection{};
};

double wrap360(double angle);
double angleError(double target, double current);
bool validFlight(const Flight& sample);

struct Position {
    double latitude;
    double longitude;
};

struct LegGuidance {
    double course{};           // True track to command
    double distanceNm{};
    double alongNm{};
    double legLengthNm{};
};

LegGuidance guideLeg(Position origin, Position destination, Position aircraft,
                     double groundSpeed);

class Controller {
public:
    void engage(const Flight& flight, Controls initial);
    Output update(const Flight& flight, const Limits& limits, const Targets& targets,
                  double lateralError, bool managesThrottle, double dt);

private:
    Controls output_{};
    double pitchTrim_{};
    double rollTrim_{};
    double throttleTrim_{};
    double filteredIas_{};
    double filteredAcceleration_{};
    double filteredVs_{};
    double liftAngle_{};
    Protection protection_{};
};

}  // namespace levelpilot
