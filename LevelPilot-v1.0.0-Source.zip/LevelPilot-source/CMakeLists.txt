cmake_minimum_required(VERSION 3.20)
project(LevelPilot VERSION 1.0.0 LANGUAGES CXX)

if(NOT WIN32 AND NOT CMAKE_SYSTEM_NAME STREQUAL "Linux")
    message(FATAL_ERROR "LevelPilot's build is configured for Windows x64 and Linux x64.")
endif()
if(NOT CMAKE_SIZEOF_VOID_P EQUAL 8)
    message(FATAL_ERROR "X-Plane requires a 64-bit plugin.")
endif()

set(XPLANE_SDK_ROOT "" CACHE PATH "Path to the extracted Laminar Research SDK directory")
if(NOT XPLANE_SDK_ROOT)
    set(XPLANE_SDK_ROOT "${CMAKE_BINARY_DIR}/laminar/SDK")
    if(NOT EXISTS "${XPLANE_SDK_ROOT}/CHeaders/XPLM/XPLMPlugin.h")
        set(sdk_archive "${CMAKE_BINARY_DIR}/XPSDK400.zip")
        file(DOWNLOAD
            "https://developer.x-plane.com/wp-content/plugins/code-sample-generation/sdk_zip_files/XPSDK400.zip"
            "${sdk_archive}"
            EXPECTED_HASH SHA256=6d7a1d36e51764554bf5e17a5ff13df1a48187b828172c6752868ddde24c938e
            TLS_VERIFY ON TIMEOUT 60
        )
        file(MAKE_DIRECTORY "${CMAKE_BINARY_DIR}/laminar")
        file(ARCHIVE_EXTRACT INPUT "${sdk_archive}" DESTINATION "${CMAKE_BINARY_DIR}/laminar")
    endif()
endif()
if(NOT EXISTS "${XPLANE_SDK_ROOT}/CHeaders/XPLM/XPLMPlugin.h")
    message(FATAL_ERROR "Set XPLANE_SDK_ROOT to the extracted SDK folder that contains CHeaders.")
endif()

set(CMAKE_CXX_STANDARD 17)
set(CMAKE_CXX_STANDARD_REQUIRED ON)
set(CMAKE_CXX_EXTENSIONS OFF)
set(CMAKE_MSVC_RUNTIME_LIBRARY "MultiThreaded$<$<CONFIG:Debug>:Debug>")

add_library(xplm_headers INTERFACE)
target_include_directories(xplm_headers INTERFACE "${XPLANE_SDK_ROOT}/CHeaders/XPLM")
target_compile_definitions(xplm_headers INTERFACE XPLM200=1 XPLM210=1 XPLM300=1 XPLM301=1)

set(plugin_sources src/controller.cpp src/simulator.cpp src/plugin.cpp)
add_library(levelpilot MODULE ${plugin_sources})
target_link_libraries(levelpilot PRIVATE xplm_headers)
set_target_properties(levelpilot PROPERTIES PREFIX "" OUTPUT_NAME "LevelPilot" SUFFIX ".xpl")
if(WIN32)
    target_compile_definitions(xplm_headers INTERFACE IBM=1)
    target_link_libraries(levelpilot PRIVATE "${XPLANE_SDK_ROOT}/Libraries/Win/XPLM_64.lib")
    if(MINGW)
        target_link_options(levelpilot PRIVATE -static)
    endif()
    set(plugin_dir win_x64)
else()
    target_compile_definitions(xplm_headers INTERFACE LIN=1)
    set_target_properties(levelpilot PROPERTIES CXX_VISIBILITY_PRESET hidden)
    set(plugin_dir lin_x64)
endif()

function(enable_warnings target)
    if(MSVC)
        target_compile_options(${target} PRIVATE /W4 /permissive-)
        target_compile_definitions(${target} PRIVATE _CRT_SECURE_NO_WARNINGS)
    else()
        target_compile_options(${target} PRIVATE -Wall -Wextra -Wpedantic)
    endif()
endfunction()

enable_warnings(levelpilot)
install(TARGETS levelpilot
    LIBRARY DESTINATION "LevelPilot/${plugin_dir}"
    RUNTIME DESTINATION "LevelPilot/${plugin_dir}"
)
install(FILES INSTALL.txt DESTINATION LevelPilot)

include(CTest)
if(BUILD_TESTING)
    add_executable(controller_tests tests/controller_test.cpp src/controller.cpp)
    target_include_directories(controller_tests PRIVATE src)
    enable_warnings(controller_tests)
    add_test(NAME controller COMMAND controller_tests)

    if(NOT WIN32)
        add_executable(plugin_tests tests/plugin_test.cpp ${plugin_sources})
        target_link_libraries(plugin_tests PRIVATE xplm_headers)
        enable_warnings(plugin_tests)
        add_test(NAME plugin_lifecycle COMMAND plugin_tests)
    endif()
endif()
