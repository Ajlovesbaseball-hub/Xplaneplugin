# LevelPilot

LevelPilot is an experimental X-Plane 12 plugin that flies a conventional fixed-wing aircraft in cruise, climbs, descents, and en-route turns. Engage it in flight to capture the current magnetic heading, altitude, and indicated airspeed.

## Install the Windows release

1. Exit X-Plane and extract the release ZIP.
2. Drag `LevelPilot` into `X-Plane 12/Resources/plugins`.
3. Confirm the binary is at `Resources/plugins/LevelPilot/win_x64/LevelPilot.xpl`.
4. Open **Plugins → LevelPilot → Flight panel**.

The release ZIP contains a Windows x64 build. The compiled plugin uses X-Plane's SDK runtime and Windows system libraries. See [INSTALL.txt](INSTALL.txt) for the first flight and control handoff.

## Flight panel

| Control | Behavior |
| --- | --- |
| Engage / Capture | Takes over pitch and roll. Captures magnetic heading, geometric MSL altitude, and IAS. Autothrottle is enabled by default. |
| Heading, altitude, and IAS | Adjusts targets in steps of 5°, 500 ft, and 5 knots. Changing heading while in GPS mode selects heading hold. |
| Capture Now | Copies current heading, altitude, and IAS into the controller. |
| Panel Targets | Copies stock aircraft autopilot selections. Selected barometric altitude is translated to a geometric MSL target at capture. IAS is copied when the selection is in knots and within the aircraft's bounds. |
| GPS Route | Follows the active waypoint exposed by the stock GPS/FMS using a look-ahead point along the leg. The GPS/FMS handles waypoint sequencing. LevelPilot captures the current heading after loss of navigation data or reaching the end of a leg that fails to sequence. |
| Auto Throttle | Toggles throttle takeover while in standby. |
| Disconnect | Releases the pitch, roll, and throttle overrides owned by LevelPilot. |

The custom X-Plane commands live under `levelpilot/flight/`. Bind `levelpilot/flight/disconnect` for a dedicated disconnect button. Moving a supported assigned hardware axis also releases control. LevelPilot starts in standby and stays in standby after a disconnect until the pilot engages it again.

## Controller

- Pitch and roll commands are sent through the standard per-axis joystick overrides before X-Plane integrates the flight model.
- Heading error sets a bank target with turn-rate and bank limits. Altitude error sets a bounded climb or descent rate. Body-rate feedback damps pitch and roll, and bounded integrators compensate for steady control loads.
- Autothrottle sends bounded forward commands per engine and blends from existing engine settings. IAS and acceleration feedback drive speed corrections.
- Stall annunciation, speed or Mach limits, and low AGL can modify the targets. Sustained high commands with little measured surface deflection and angular response trigger disconnection.
- The plugin releases control when the sim enters replay, detected stock autopilot servos activate, or flight updates become invalid. It also releases below 350 ft AGL, outside its assisted flight envelope, and when the player's aircraft changes.

The tuning uses broad light-aircraft and transport defaults. Start with the stock Cessna 172 in stable cruise, above 750 ft AGL, at 1x sim rate, with the aircraft AP off. Pilot tasks include takeoff, approach, landing, traffic separation, and terrain clearance. Custom flight-control add-ons can interfere with standard datarefs.

## Build from source

Use CMake 3.20+ and a C++17 compiler. On Windows install Visual Studio Build Tools with **Desktop development with C++** and open a developer terminal.

```powershell
cmake -S . -B build -A x64
cmake --build build --config Release --parallel
ctest --test-dir build -C Release --output-on-failure
cmake --install build --config Release --prefix out
```

The install target creates `out/LevelPilot`. CMake downloads and verifies the Laminar SDK automatically. To use a local copy, add `-DXPLANE_SDK_ROOT=C:/path/to/SDK` at configure time. The path should contain the SDK's `CHeaders` directory.

On Linux x64, omit `-A x64` and configure with `-DCMAKE_BUILD_TYPE=Release`. Linux additionally runs the mock XPLM host tests. The GitHub Actions workflow builds and tests both targets and creates the Windows install ZIP as a CI artifact.

## Verification

Controller tests cover heading wraparound, waypoint guidance, speed protection and closed-loop captures with synthetic light-aircraft and transport flight dynamics. The mock host exercises plugin startup, panel controls, GPS mode, override conflicts, joystick takeover and cleanup. Flight behavior and compatibility still need verification in a live copy of X-Plane 12.

[Laminar SDK and plugin packaging documentation](https://developer.x-plane.com/article/building-and-installing-plugins/)
